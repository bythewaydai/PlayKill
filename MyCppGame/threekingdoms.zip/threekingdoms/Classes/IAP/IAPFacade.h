//
//  IAPFacade.h
//  threeKingdoms
//
//  Created by lee song on 14-2-28.
//
//

#ifndef __threeKingdoms__IAPFacade__
#define __threeKingdoms__IAPFacade__

#include <iostream>

void buy(int type);

#endif /* defined(__threeKingdoms__IAPFacade__) */
