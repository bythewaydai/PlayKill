//
//  CommonTitle.h
//  threeKingdoms
//
//  Created by .m on 14-2-11.
//
//

#ifndef __threeKingdoms__CommonTitle__
#define __threeKingdoms__CommonTitle__

#include <iostream>

#endif /* defined(__threeKingdoms__CommonTitle__) */
