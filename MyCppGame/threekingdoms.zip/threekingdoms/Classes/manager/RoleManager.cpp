//
//  RoleManager.cpp
//  threeKingdoms
//
//  Created by .m on 13-12-27.
//
//

#include "RoleManager.h"

bool RoleManager::init()
{
    return true;
}

int RoleManager::getRoleId()
{
    return 1;
}